import React from 'react';
import { useNavigate } from 'react-router-dom';
import './StartScreen.css';
const StartScreen = () => {
  const navigate = useNavigate();
  const startQuiz = () => {
    navigate('/quiz');
  };

  return (
    <div className="start-screen-container">
      <h1>Welcome to Quiz Challenge</h1>
      <img className="quiz-image" src="../src/assets/images/quizChallenge.jpg"></img>

      <h3>Instructions</h3>
      <ul>
        <li>Each question has 4 multiple choices, you have to choose the correct option</li>
        <li>You have 10 seconds to answer each question</li>
        <li>The timer will start as soon as you click the start button</li>
        <li>Good luck!</li>
      </ul>
      
      <button onClick={startQuiz} className="start-button">Start</button>
    </div>
  );
};

export default StartScreen;
