import React, { useRef, useState, useEffect } from 'react';
import './Quiz.css';
import { data } from '../../assets/data';

const Quiz = () => {
    const [index, setIndex] = useState(0);
    const [question, setQuestion] = useState(data[0]);
    const [lock, setLock] = useState(false);
    const [score, setScore] = useState(0);
    const [result, setResult] = useState(false);
    const [timer, setTimer] = useState(10); // Timer in seconds

    const Option1 = useRef(null);
    const Option2 = useRef(null);
    const Option3 = useRef(null);
    const Option4 = useRef(null);
    const nextButtonRef = useRef(null); // Ref for the Next button

    const option_array = [Option1, Option2, Option3, Option4];

    useEffect(() => {
        if (timer > 0 && !lock) {
            const interval = setInterval(() => {
                setTimer(prev => prev - 1);
            }, 1000);

            return () => clearInterval(interval);
        } else if (timer === 0 && !lock) {
            // Timer expired
            setLock(true);
            option_array[question.ans - 1].current.classList.add('correct');
            // Programmatically click the Next button after 2 seconds
            setTimeout(() => {
                if (nextButtonRef.current) {
                    nextButtonRef.current.click();
                }
            }, 2000); // 2 seconds delay
        }
    }, [timer, lock, question]);

    useEffect(() => {
        if (!result) {
            setQuestion(data[index]);
            setTimer(10);
            setLock(false);
        }
    }, [index, result]);

    const checkAns = (e, ans) => {
        if (!lock) {
            if (question.ans === ans) {
                e.target.classList.add('correct');
                setLock(true);
                setScore(prev => prev + 1);
            } else {
                e.target.classList.add('incorrect');
                setLock(true);
                option_array[question.ans - 1].current.classList.add('correct');
            }

            // Programmatically click the Next button after a short delay
            setTimeout(() => {
                if (nextButtonRef.current) {
                    nextButtonRef.current.click();
                }
            }, 1000); // 1 second delay to show the result
        }
    };

    const handleNext = () => {
        if (lock) {
            // Remove styles from all options
            option_array.forEach(option => {
                if (option.current) {
                    option.current.classList.remove('correct');
                    option.current.classList.remove('incorrect');
                }
            });

            if (index === data.length - 1) {
                setResult(true);
            } else {
                setIndex(prev => prev + 1);
            }
        }
    };

    const reset = () => {
        setIndex(0);
        setLock(false);
        setScore(0);
        setResult(false);
        setTimer(10); // Reset timer
    };

    return (
        <div className='container'>
            <h1>Quiz Challenge</h1>
            <hr/>
            {result ? (
                <>
                    <h3>Your Score: {score/data.length*100} out of {data.length/data.length*100}</h3>
                    <button onClick={reset}>Play Again</button>
                </>
            ) : (
                <>
                    <h2>{index + 1}. {question.question}</h2>
                    <img src={question.picture} alt="" />
                    <ul className='options'>
                        <li ref={Option1} onClick={(e) => checkAns(e, 1)}>{question.option1}</li>
                        <li ref={Option2} onClick={(e) => checkAns(e, 2)}>{question.option2}</li>
                        <li ref={Option3} onClick={(e) => checkAns(e, 3)}>{question.option3}</li>
                        <li ref={Option4} onClick={(e) => checkAns(e, 4)}>{question.option4}</li>
                    </ul>
                    <div className="timer">Time left: {timer}s</div>
                    <button
                        ref={nextButtonRef} 
                        onClick={handleNext} 
                        disabled={!lock} id='next-btn'
                    >
                        Next
                    </button>
                    <div className="index">{index + 1} of {data.length} questions</div>
                </>
            )}
        </div>
    );
};

export default Quiz;
