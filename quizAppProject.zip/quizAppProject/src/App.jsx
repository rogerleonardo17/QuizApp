import React, { useState } from 'react';
import Quiz from './Components/Quiz/Quiz';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import StartScreen from './Components/StartScreen/StartScreen';

const App = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<StartScreen/>} />
        <Route path="/quiz" element={<Quiz/>} />
      </Routes>
    </Router>
  );
};

export default App;
